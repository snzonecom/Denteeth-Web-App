export default function Contact() {
    return(
        <div>

        <div class="bg-[#dfefff]">

            <div className="mt-4 grow flex items-center justify-around">

                <div className="mb-2">

                    <h1 className="text-[55px] font-semibold text-center mb-6 mt-20"></h1>
                </div>
            </div>

        </div>

        <div class="container-fluid mx-auto bg-[#dfefff]">
        <div class="flex flex-wrap mx-20 items-center">

            <div class="w-full md:w-1/2 px-4 mb-8">
            <div class="p-4">

                <img src="../images/contact-map.png" class="shadow-xl" />


            </div>
            </div>

            <div class="w-full md:w-1/2 px-4 mb-8">
            <div class="p-4">
                <h1 class="text-left text-[60px] mb-6 text-[#002451] font-bold">CONTACT US</h1>

                <p class="text-left text-[17px] text-[#424244]">
                We welcome your feedback and suggestions to enhance our services further. Your input is invaluable in helping us improve and tailor Denteeth to meet your needs effectively. Let us know how we can better serve you and make your dental care experience even more exceptional.
                
                <br /><br />
                
                Contact Denteeth today, and let us partner with you on your journey to optimal oral health. Your smile matters, and so does your experience with us. We look forward to hearing from you!
                </p>

                </div>

                    <div class="mt-4 flex space-x-4">

                        <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                            <button class="bg-[#002451] text-white ml-4 py-2 px-4 rounded-md ml-0">Facebook</button>
                        </a>

                        <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
                            <button class="bg-[#002451] text-white py-2 px-4 rounded-md">Twitter</button>
                        </a>

                        <a href="https://www.Instagram.com" target="_blank" rel="noopener noreferrer">
                            <button class="bg-[#002451] text-white py-2 px-4 rounded-md">Instagram</button>
                        </a>
                        
                    </div>
                    </div>

                    <div class="w-full md:w-1/4 px-4 mb-40">
                    <div class="p-4">

            </div>
            </div>

          </div>
            </div>
            </div>

    );
}