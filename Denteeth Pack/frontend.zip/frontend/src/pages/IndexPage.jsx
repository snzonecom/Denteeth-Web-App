export default function IndexPage() {
    return(
        <div>

        <div class="bg-[#dfefff]">

            <div className="mt-4 grow flex items-center justify-around">

                <div className="mb-2">

                    <h1 className="text-[55px] font-semibold text-center mb-6 mt-20"></h1>
                </div>
            </div>

        </div>

        <div class="container-fluid mx-auto bg-[#dfefff]">
        <div class="flex flex-wrap mx-32 items-center">

            <div class="w-full md:w-1/2 px-4 mb-8">
            <div class="p-4">
                <p class="text-[#536ec8] text-[23px] font-semibold">Denteeth.</p>
                <h1 class="text-left text-[60px] mb-6 mt-4 text-[#002451] font-bold leading-[4.2rem] ">
                    YOUR SMILE MATTERS, AND SO DOES YOUR
                    EXPERIENCE WITH US!
                </h1>

                <p class="text-left text-[17px] text-[#424244] mb-6">
                At Denteeth, we understand the significance of your smile, and we are dedicated to ensuring that every aspect of your dental care
                experience is exceptional. Our mission goes beyond just providing a platform for convenient dental bookings;
                it is about prioritizing your comfort, well-being, and satisfaction.
                </p>

                <a href="/register">
                    <button class="bg-[#536ec8] text-white ml-0 py-4 px-7 rounded-md ml-0">Join Our Community Now</button>
                </a>

            </div>
            </div>

            <div class="w-full md:w-1/2 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Dental Examinations.png" class="max-w-[70%] mx-auto block mb-4"/>
            </div>
            </div>


            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">

            </div>
            </div>
            
        </div>

        
        </div>
        
            <div class="flex flex-wrap mx-16">
                
                <div class="container-fluid mx-auto bg-transparent mt-14">
                    <div class="flex flex-wrap mx-32 items-center">

                <div class="w-full md:w-1/2 px-0 mb-8">
                <div class="p-4">
                    <img src="../../images/quality-service.png" class="max-w-[90%] mx-auto block mb-4"/>
                </div>

                </div>

                <div class="w-full md:w-1/2 px-0 pr-4 mb-8">

                <div class="p-4">
                    <p class="text-[#536ec8] text-[23px] font-semibold">About Us</p>
                    <h1 class="text-left text-[60px] mb-6 mt-4 text-[#002451] font-bold leading-[4.2rem] ">
                        ONLY QUALITY SERVICE
                    </h1>

                    <p class="text-left text-[17px] text-[#424244] mb-6">
                    Our commitment is straightforward and unwavering – we stand for only quality service.
                    When it comes to your dental care, we prioritize excellence in every interaction and appointment.

                    <br /><br />
                    Choose Denteeth for a dental experience where quality is not just a promise but a practice.
                    Your satisfaction is our priority, and we are here to redefine what quality dental service truly means. 
                    </p>

                    <a href="/about">
                        <button class="bg-[#536ec8] text-white ml-0 py-4 px-7 rounded-md ml-0">Know More About Us</button>
                    </a>

                </div>

                </div>


                <div class="w-full md:w-1/4 px-4 mb-8">
                <div class="p-4">

                </div>
                </div>
                
            </div>

            
            </div>
            
            </div>

            <div class="flex flex-wrap">
                
                <div class="container-fluid mx-auto bg-[#f6f6f6] mt-0">
                    <div class="flex flex-wrap mx-32 items-center">

                <div class="w-full md:w-3/3 px-0 mb-8">
                <div class="p-4">
                <p class="text-[#536ec8] text-[23px] font-semibold text-center mt-12">TOP SERVICES</p>
                <h1 class="text-[60px] text-[#282c2d] font-bold text-center">
                        What We Offer
                    </h1>
                </div>

                </div>

                <div class="w-full md:w-1/4 px-4 pr-4 mb-8">

                    <div class="p-4">
                        <img src="../images/Orthodontic Services.png" class="mx-auto block mb-4 max-w-[70%]"/>
                        <p class="text-[#002451] text-[23px] text-center mb-4 font-semibold">Orthodontic Services</p>

                        <p class="text-center text-[17px] text-[#424244] mb-6">
                        Orthodontic treatments, such as braces or clear aligners, are provided to correct misaligned teeth and jaws, improving both aesthetics and functionality.
                        </p>
                    </div>

                </div>

                <div class="w-full md:w-1/4 px-4 pr-4 mb-8">

                    <div class="p-4">
                        <img src="../images/Cosmetic Dentistry.png" class="mx-auto block mb-4 max-w-[70%]"/>
                        <p class="text-[#002451] text-[23px] text-center mb-4 font-semibold">Cosmetic Dentistry</p>

                        <p class="text-center text-[17px] text-[#424244] mb-6">
                        Various aesthetic treatments, such as veneers, bonding, and contouring, aimed at enhancing the overall appearance of the smile.
                        </p>
                    </div>

                </div>

                <div class="w-full md:w-1/4 px-4 pr-4 mb-8">

                    <div class="p-4">
                        <img src="../images/Oral Surgery.png" class="mx-auto block mb-4 max-w-[70%]"/>
                        <p class="text-[#002451] text-[23px] text-center mb-4 font-semibold">Oral Surgery</p>

                        <p class="text-center text-[17px] text-[#424244] mb-6">
                        Surgical procedures performed in the oral cavity, including tooth extractions, wisdom tooth removal, and other corrective surgeries.
                        </p>
                    </div>

                </div>

                <div class="w-full md:w-1/4 px-4 pr-4 mb-8">

                    <div class="p-4">
                        <img src="../images/Pediatric Dentistry.png" class="mx-auto block mb-4 max-w-[70%]"/>
                        <p class="text-[#002451] text-[23px] text-center mb-4 font-semibold">Pediatric Dentistry</p>

                        <p class="text-center text-[17px] text-[#424244] mb-6">
                        Specialized care for children, including preventive measures, education on oral hygiene, and early intervention for potential dental issues.
                        </p>
                    </div>

                </div>
                
            </div>

            
            </div>
            
            
            </div>

            <p class="text-[#536ec8] text-[50px] font-semibold text-center mt-20">Frequently Asked Questions</p>

            <section class="container mx-auto max-w-[60%] mt-8 p-4">

                <div class="bg-white border border-gray-300 rounded-md p-4 mb-6">
                    <h3 class="text-lg font-semibold text-[#002451] mb-2">Q1: How can I manage dental anxiety?</h3>
                    <p class="text-gray-700">Communicate your concerns with your dentist, who can explain procedures and provide reassurance. Some dental offices offer sedation options for anxious patients.
                    Listening to music or practicing deep breathing during appointments may also help manage anxiety.</p>
                </div>

                <div class="bg-white border border-gray-300 rounded-md p-4 mb-6">
                    <h3 class="text-lg font-semibold text-[#002451] mb-2">Q2: What should I do in a dental emergency?</h3>
                    <p class="text-gray-700">In case of a dental emergency, contact your dentist immediately.
                    If it's after hours, visit the nearest emergency room. For a knocked-out tooth, rinse it gently, 
                    place it back in the socket if possible, or store it in milk and seek immediate dental care.</p>
                </div>

                <div class="bg-white border border-gray-300 rounded-md p-4 mb-6">
                    <h3 class="text-lg font-semibold text-[#002451] mb-2">Q3: What is the best way to prevent cavities?</h3>
                    <p class="text-gray-700">The best way to prevent cavities is to maintain good oral hygiene practices,
                     including regular brushing and flossing, a balanced diet, and routine dental check-ups.
                    Dental sealants and fluoride treatments can also provide additional protection.</p>
                </div>

                <div class="bg-white border border-gray-300 rounded-md p-4 mb-6">
                    <h3 class="text-lg font-semibold text-[#002451] mb-2">Q4: How often should I visit the dentist for a check-up?</h3>
                    <p class="text-gray-700">It is generally recommended to visit the dentist for a routine check-up and cleaning every six months. 
                    However, your dentist may suggest a different schedule based on your individual oral health needs.</p>
                </div>

                <div class="bg-white border border-gray-300 rounded-md p-4 mb-6">
                    <h3 class="text-lg font-semibold text-[#002451] mb-2">Q5: Are dental X-rays safe?</h3>
                    <p class="text-gray-700">Yes, dental X-rays are safe, and the amount of radiation exposure is minimal. Dentists use lead aprons and high-speed film or digital sensors to further reduce radiation exposure. 
                    X-rays are crucial for diagnosing dental issues not visible during a regular examination.</p>
                </div>

                <div class="mb-16"></div>

            </section>

            <footer class="bg-gray-800 text-white p-4 text-center">
                <p>&copy; 2023 Denteeth - Dental Services. All rights reserved.</p>
            </footer>

    </div> 
    );
}