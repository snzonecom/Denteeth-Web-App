export default function DentistG() {
    return(
    <div>

        <div class="bg-[#dfefff]">
            <div class = " min-h-screen container mx-auto mt-4">
                <div class = "grid grid-cols-1">
                    {/* card 1 */}
                    <div class = "container mx-auto rounded-[15px] shadow-lg bg-white p-[50px] max-w-[1000px] m-[5%]">
                        <div class = "grid grid-row-3 grid-cols-3 gap-2 ">
                            <div class = "item-center rounded-xl overflow-hidden text-center row-start-1 row-span-2 col-1">
                                <img class = "item-center rounded-full" src = "../../images/doctor-img06.png" alt = "" />
                                <h5 class="text-[20px] text-[#536ec8] text-center font-semibold pt-4">DENTIST</h5>
                                <div class="py-[5px] flex items-center mb-1 mt-2 space-x-1 rtl:space-x-reverse place-content-center">
                                    <svg class="w-4 h-4 text-yellow-300" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
                                    </svg>
                                    <svg class="w-4 h-4 text-yellow-300" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
                                    </svg>
                                    <svg class="w-4 h-4 text-yellow-300" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
                                    </svg>
                                    <svg class="w-4 h-4 text-yellow-300" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
                                    </svg>
                                    <svg class="w-4 h-4 text-yellow-300" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
                                    </svg>
                                </div>
                                <h3 class="text-center text-[#424244]">Dental X-ray/Dental Examinations</h3><br></br>
                                <div class = "hover:scale-105 ease-in-out duration-300 mb-4">
                                    <a href= "/appointment" class = "shadow-xl bg-[#002451] text-white py-3 px-8 w-[80%] rounded-full mt-5">Book an Appointment </a>
                                </div>
                                
                                
                            </div>
                            <div class = "text-center row-start-2">
                                
                            </div>
                            <div class="items-left place-content-left py-[5px] mb-1 ml-8 row-start-1 row-span-2 col-start-2 col-span-2">
                                <h1 className="text-[50px] text-[#536ec8] font-bold text-left mb-5 mt-5">Dr. Wilson Simson</h1>
                                <p class="text-lg text-[20px] mb-2 text-[#424244] text-left font-semibold">Breif Information</p>
                                <p class="text-justify text-[#424244]">He specialized in Dental X-rays that can help your dentist detect oral health issues, like cavities and gum disease, before they worsen. There are many different types of dental X-rays, including intraoral (taken inside your mouth) and extraoral (taken outside your mouth). Dental X-rays are essential to proper oral health and maintenance.</p>
                                <br></br>
                                <p class="text-lg text-[20px] mb-2 text-[#424244] text-left font-semibold">Education</p>
                                <p class="text-justify text-[#424244]">In University of Bern where Dr. Wilson graduated from Switzerland with a Doctor of Dental Surgery (DDS) degree.</p>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    

    );
}