import { useLocation } from 'react-router-dom';

export default function User() {
    const location = useLocation();
    const email = location.state && location.state.id;
    
    return(
        <div>

        <div class="bg-[#dfefff]">
            <div class = " min-h-screen container mx-auto mt-4">
                <div class = "grid grid-cols-1">
                    {/* card 1 */}
                    <div class = "container mx-auto rounded-[15px] shadow-lg bg-white p-[50px] max-w-[1000px] m-[5%]">
                        <div class = "grid grid-row-2 grid-cols-3 gap-2 ">
                            <div class = "item-center rounded-xl overflow-hidden text-center pt-5 mb-[-30px]">
                                <img class = "item-center rounded-full" src = "../../images/user2.png" alt = "" />
                                
                            </div>
                            <div class = "text-center row-start-2">
                                <h5 class="text-[20px] text-[#536ec8] text-center font-semibold">NAME OF USER</h5>
                                <h3 class="text-center text-[#424244]">{email}</h3>
                                <button class = "hover:scale-105 ease-in-out duration-300 shadow-xl bg-[#1f1e1e] text-white py-2.5 w-[80%] rounded-full mt-5">Logout</button>
                                <button class = "hover:scale-105 ease-in-out duration-300 shadow-xl bg-[#d10f18] text-white py-2.5 w-[80%] rounded-full mt-5">Delete account</button>
                            </div>

                            <div class="items-left place-content-left py-[5px] ml-10 mb-1 row-start-1 row-span-2 cal-start-2 col-span-2">
                                <h1 className="text-[50px] text-[#536ec8] font-bold text-left mb-5">MY APPOINTMENTS:</h1>
                                <div class="container mx-auto rounded-[15px] shadow-lg bg-[#dfefff] p-2 text-[#002451]">
                                    <table class="table-auto text-left border-separate border-spacing-8">
                                        <thead>
                                            <tr>
                                            <th>DENTIST NAME</th>
                                            <th>SERVICE</th>
                                            <th>STATUS</th>
                                            <th>BOOKED ON</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                            <td>FULL NAME HERE</td>
                                            <td>SERVICE</td>
                                            <td>UNPAID</td>
                                            <td>MM/DD/YYYY</td>
                                            </tr>
                                            <tr>
                                            <td>FULL NAME HERE</td>
                                            <td>SERVICE</td>
                                            <td>PAID</td>
                                            <td>MM/DD/YYYY</td>
                                            </tr>
                                            <tr>
                                            <td>FULL NAME HERE</td>
                                            <td>SERVICE</td>
                                            <td>PAID</td>
                                            <td>MM/DD/YYYY</td>
                                            </tr>
                                            <tr>
                                            <td>FULL NAME HERE</td>
                                            <td>SERVICE</td>
                                            <td>PAID</td>
                                            <td>MM/DD/YYYY</td>
                                            </tr>
                                            <tr>
                                            <td>FULL NAME HERE</td>
                                            <td>SERVICE</td>
                                            <td>PAID</td>
                                            <td>MM/DD/YYYY</td>
                                            </tr>
                                            <tr>
                                            <td>FULL NAME HERE</td>
                                            <td>SERVICE</td>
                                            <td>PAID</td>
                                            <td>MM/DD/YYYY</td>
                                            </tr>
                                            <tr>
                                            <td>FULL NAME HERE</td>
                                            <td>SERVICE</td>
                                            <td>PAID</td>
                                            <td>MM/DD/YYYY</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    

    );
}