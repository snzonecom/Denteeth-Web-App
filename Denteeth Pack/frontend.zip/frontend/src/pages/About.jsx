export default function About() {
    return(
        <div>

        <div class="bg-[#dfefff]">

            <div className="mt-4 grow flex items-center justify-around">

                <div className="mb-2">

                    <h1 className="text-[55px] font-semibold text-center mb-6 mt-20"></h1>
                </div>
            </div>

        </div>

        <div class="container-fluid mx-auto bg-[#dfefff]">
        <div class="flex flex-wrap mx-20 items-center">

            <div class="w-full md:w-3/5 px-4 mb-8">
            <div class="p-4">
                <h1 class="text-left text-[60px] mb-6 text-[#002451] font-bold">ABOUT DENTEETH</h1>

                <p class="text-left text-[17px] text-[#424244] mb-6">
                Access to healthcare services is crucial for maintaining and enhancing public
                health. However, scheduling doctor visits may be difficult, time-consuming, and
                inefficient. Patients may endure long waits, trouble scheduling appointments, and
                difficulties locating healthcare professionals with the expertise needed. Healthcare
                workers, on the other hand, struggle with managing appointments and reducing
                no-shows.To address these issues, our output focuses on the development of a clinic
                appointment booking web application. This platform aims to streamline the appointment
                booking process, making it easier and more convenient for patients to connect with
                healthcare providers
                </p>


                <p class="text-left text-[17px] text-[#424244]">
                In an era of increasing digitalization and technological advancement, the Denteeth clinic appointment booking web application seeks to bridge the gap between
            patients and healthcare providers. With the growing reliance on smartphones and the
            internet, proponents recognize the need to modernize the way healthcare appointments
            are scheduled and managed. The web application is expected to offer a user-friendly and
            accessible solution that caters to the evolving needs of patients and healthcare
            professionals.
                </p>


            </div>
            </div>

            <div class="w-full md:w-2/5 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/denteeth-logo.png" class="max-w-[65%] mx-auto block mb-4"/>
            </div>
            </div>


            <div class="w-full md:w-1/4 px-4 mb-24">
            <div class="p-4">

            </div>
            </div>
            
        </div>

        
        </div>

            <div class="bg-transparent">
                <div className="mt-4 grow flex items-center justify-around">

                    <div className="mb-2">

                        <h1 className="text-[55px] text-[#002451] font-semibold text-center mb-6 mt-12">The Developers</h1>
                    </div>
                </div>
            </div>

            <div class="flex flex-wrap mx-16">
                
                <div class="w-full md:w-1/4 px-2 mb-40">
                <div class="p-2">
                    <img src="../../images/Ez.png" class="max-w-[80%] mx-auto block mb-4"/>
                    <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Castro, Ezralyn</p>
                    <p class="text-center text-[#424244]">developer</p>
                </div>
                </div>

                <div class="w-full md:w-1/4 px-2 mb-40">
                <div class="p-2">
                    <img src="../../images/nicks.png" class="max-w-[80%] mx-auto block mb-4"/>
                    <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Notra, Nickaella</p>
                    <p class="text-center text-[#424244]">developer</p>
                </div>
                </div>

                <div class="w-full md:w-1/4 px-2 mb-40">
                <div class="p-2">
                    <img src="../../images/shane.jpg" class="max-w-[80%] mx-auto block mb-4"/>
                    <p class="text-lg text-[22px] mb-1 text-[#536ec8] text-center font-semibold">Paras, Shane</p>
                    <p class="text-center text-[#424244]">developer</p>
                </div>
                </div>

                <div class="w-full md:w-1/4 px-2 mb-40">
                <div class="p-2">
                    <img src="../../images/Denden.png" class="max-w-[80%] mx-auto block mb-4"/>
                    <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Santos, Denise</p>
                    <p class="text-center text-[#424244]">developer</p>
                </div>
                </div>
            
            </div>

    </div> 
    );
}