import { useState } from "react";
import axios from 'axios';

export default function Appointment() {
    
    const [fullName, setFullName] = useState("");
    const [email, setEmail] = useState("");
    const [contact, setContact] = useState("");
    const [service, setService] = useState("");
    const [appointmentSched, setappointmentSched] = useState("");
    const [appointmentStatus, setappointmentStatus] = useState(null);

    const handleAppointment = (e) => {
        e.preventDefault();
    
        // Format the date to ISO format
        const formattedDate = new Date(appointmentSched).toISOString();
    
        axios.post("http://127.0.0.1:3001/setAppointment", {
            fullName,
            email,
            contact,
            service,
            appointmentSched: formattedDate,
        })
        .then(result => {
            console.log(result);
            // Clear the form fields after successful registration
            setFullName("");
            setEmail("");
            setContact("");
            setService("");
            setappointmentSched("");
            // Set registration status for displaying notification
            setappointmentStatus("success");
        })
        .catch(err => {
            console.log(err);
            // Set registration status for displaying notification
            setappointmentStatus("error");
        });
    }

    return(
    <div>

        <div class="bg-[#dfefff]">
            <div class = " min-h-screen container mx-auto mt-2">
                <div class = "container">
                    <div className="mt-4 grow flex items-center justify-around">
                        <div className="mb-2">
                            <h1 className="text-[65px] text-[#536ec8] font-bold text-center mb-10 mt-16">BOOK AN APPOINTMENT</h1>
                        </div>
                    </div>
                </div>
                <div class = "container mx-auto mb-[100px] rounded-[15px] shadow-lg bg-white p-[50px] max-w-[550px] grid grid-cols-1">
                    <form onSubmit={handleAppointment}>
                        <div>
                            <div class = "m-3">
                                <span class="after:content-['*'] after:ml-0.5 after:text-red-500 pl-2 text-[15px] text-[#536ec8] text-center font-semibold pt-4">Full Name</span><br></br>
                                <input class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-sky-500 block w-full rounded-md sm:text-sm focus:ring-1" type="text" placeholder="Enter your first name" required 
                                value={fullName}
                                onChange={(e) => setFullName(e.target.value)} />
                            </div>
                            <div class = "m-3">
                                <span class="after:content-['*'] after:ml-0.5 after:text-red-500 pl-2 text-[15px] text-[#536ec8] text-center font-semibold pt-4">Email</span><br></br>
                                <input class="mt-3 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-sky-500 block w-full rounded-md sm:text-sm focus:ring-1" type="text" placeholder="Enter your email" required 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}/>
                            </div>
                            <div class = "m-3">
                                <span class="after:content-['*'] after:ml-0.5 after:text-red-500 pl-2 text-[15px] text-[#536ec8] text-center font-semibold pt-4">Contact Number</span><br></br>
                                <input class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-sky-500 block w-full rounded-md sm:text-sm focus:ring-1" type="text" placeholder="Enter your contact no" required 
                                value={contact}
                                onChange={(e) => setContact(e.target.value)}/>
                            </div>
                            <div class = "m-3">
                                <label for="countries" class="after:content-['*'] after:ml-0.5 after:text-red-500 pl-2 text-[15px] text-[#536ec8] text-center font-semibold pt-4">Service</label><br></br>
                                <select class="pl-3 mt-1 px-2 py-2.5 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-sky-500 block w-full rounded-full sm:text-sm focus:ring-1" placeholder="Choose service" required 
                                value={service}
                                onChange={(e) => setService(e.target.value)}>
                                    <option>Dental Examinations</option>
                                    <option>Dental X-rays</option>
                                    <option>Dental Fillings</option>
                                    <option>Teeth Whitening</option>
                                    <option>Orthodontic Services</option>
                                    <option>Dental Bridges</option>
                                    <option>Dental Implants</option>
                                    <option>Dentures</option>
                                    <option>Root Canal</option>
                                    <option>Periodontal Treatment</option>
                                    <option>Oral Surgery</option>
                                    <option>Pediatric Dentistry</option>
                                    <option>Mouth Guards</option>
                                    <option>Cosmetic Dentistry</option>
                                    <option>Dental Sealants</option>
                                    <option>Emergency Dental Care</option>
                                </select>
                            </div >
                            <div class = "m-3">
                                <span class="after:content-['*'] after:ml-0.5 after:text-red-500 pl-2 text-[15px] text-[#536ec8] text-center font-semibold pt-4">Appointment Date</span><br></br>
                                <input
                                    class="pl-3 mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-sky-500 block w-full rounded-full sm:text-sm focus:ring-1"
                                    type="datetime-local"
                                    value={appointmentSched}
                                    onChange={(e) => setappointmentSched(e.target.value)}
                                />
                            </div >                           
                            
                            <div class="text-center mt-5 pt-5">
                                <div class="hover:scale-105 ease-in-out duration-300">
                                    <button class="shadow-xl bg-[#002451] text-white py-3 px-8 w-[80%] rounded-full">Submit Appointment</button>
                                </div>
                            </div>



                        </div>
                    </form>
                </div>
                <div class = "container mt-4 pb-3">
                    <div className="mt-4 grow flex items-center justify-around">
                    </div>
                </div>
            </div>
        </div>
    </div>    

    );
}