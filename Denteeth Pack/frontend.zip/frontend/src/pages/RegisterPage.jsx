import { useState } from "react";
import { Link } from "react-router-dom";
import axios from 'axios';

export default function RegisterPage() {
  const [fullName, setFullName] = useState("");
  const [contact, setContact] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [registrationStatus, setRegistrationStatus] = useState(null);

  const handleRegister = (e) => {
    e.preventDefault();
    axios.post("http://127.0.0.1:3001/registerUser", { fullName, contact, email, password })
      .then(result => {
        console.log(result);
        // Clear the form fields after successful registration
        setFullName("");
        setContact("");
        setEmail("");
        setPassword("");
        // Set registration status for displaying notification
        setRegistrationStatus("success");
      })
      .catch(err => {
        console.log(err);
        // Set registration status for displaying notification
        setRegistrationStatus("error");
      });
  }

  return (
    <div className="bg-[#dfefff]">
      <div className="mt-4 grow flex items-center justify-around">
        <div className="mb-96 mt-24 bg-white px-40 py-16 rounded-[15px] shadow-lg">
          <h1 className="text-[45px] font-semibold text-[#002451] text-center">Hello,</h1>
          <h1 className="text-[45px] font-semibold text-[#002451] text-center mb-4">Welcome to Denteeth!</h1>
          <form className="max-w-md mx-auto text-center" onSubmit={handleRegister}>
            <input type="text" placeholder="Full Name" required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)} />

            <input type="number" placeholder="Contact Number" required
              value={contact}
              onChange={(e) => setContact(e.target.value)} />

            <input type="email" placeholder="your@email.com" required
              value={email}
              onChange={(e) => setEmail(e.target.value)} />

            <input type="password" placeholder="Password" required
              value={password}
              onChange={(e) => setPassword(e.target.value)} />

            <button className="primary mt-4 font-semibold text-[20px]">REGISTER NOW</button>

            {registrationStatus === "success" && (
              <div className="text-green-500"><br/>Registration successful! You can now log in.</div>
            )}

            {registrationStatus === "error" && (
              <div className="text-red-500">Registration failed. Please try again.</div>
            )}

            <div className="text-center py-4 text-gray-500">
              Already have an account?
              <Link className="font-semibold text-[#536ec8]" to={'/login'}> Login</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
