import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';

export default function LoginPage() {
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const navigate = useNavigate();

    axios.defaults.withCredentials = true;

    const handleLogin = (e) => {
        e.preventDefault();
        axios.post('http://127.0.0.1:3001/loginUser', { email, password })
            .then(result => {
                console.log(result);
                if (result.data === 'success') {
                    navigate('/user',{state: {id: email}});
                }
            })
            .catch(err => console.log(err));
    }

    return (
        <div class="bg-[#dfefff]">
            <div className="mt-4 grow flex items-center justify-around">
                <div className="mb-96 mt-24 bg-white px-40 py-16 rounded-[15px] shadow-lg">
                    <h1 className="text-[45px] font-semibold text-[#002451] text-center">Hello,</h1>
                    <h1 className="text-[45px] font-semibold text-[#002451] text-center mb-4">Welcome to Denteeth!</h1>
                    <form className="max-w-md mx-auto text-center" onSubmit={handleLogin}>
                        <input
                            type="email"
                            placeholder="your@email.com"
                            required
                            onChange={(e) => setEmail(e.target.value)}
                        />
                        <input
                            type="password"
                            placeholder="password"
                            required
                            onChange={(e) => setPassword(e.target.value)}
                        />
                        <button className="primary mt-4 font-semibold text-[20px]">LOG IN</button>
                        <div className="text-center py-4 text-gray-500">
                            Don't have an account yet?
                            <Link to={'/register'} class="font-semibold text-[#536ec8]"> Register Now</Link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
