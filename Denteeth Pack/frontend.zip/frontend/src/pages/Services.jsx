export default function Services() {
    return(
    <div>

        <div class="bg-[#dfefff]">

            <div className="mt-4 grow flex items-center justify-around">

                <div className="mb-2">

                    <h1 className="text-[65px] text-[#536ec8] font-bold text-center mb-10 mt-16">SERVICES OFFERED</h1>
                </div>
            </div>

        </div>

        <div class="container-fluid mx-auto bg-[#dfefff]">
        <div class="flex flex-wrap mx-20">

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Dental Examinations.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Dental Examinations</p>
                <p class="text-justify text-[#424244]">Regular dental check-ups involve a thorough examination of the oral cavity, including teeth, gums, and soft tissues. Professional cleanings help remove plaque and tartar, preventing issues like cavities and gum disease.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Dental X-rays.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Dental X-rays</p>
                <p class="text-justify text-[#424244]">X-rays are crucial for diagnosing hidden dental problems such as cavities between teeth, impacted teeth, and bone loss. They aid in creating a comprehensive treatment plan.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Dental Fillings.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Dental Fillings</p>
                <p class="text-justify text-[#424244]"> Dental fillings are used to repair teeth affected by decay or damage. Materials like composite resin or amalgam are used to restore the tooth's structure and function.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Teeth Whitening.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Teeth Whitening</p>
                <p class="text-justify text-[#424244]">Cosmetic dentistry service focused on enhancing the appearance of teeth. Various whitening methods, such as in-office treatments or take-home kits, are available to lighten tooth discoloration.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Orthodontic Services.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Orthodontic Services</p>
                <p class="text-justify text-[#424244]">Orthodontic treatments, such as braces or clear aligners, are provided to correct misaligned teeth and jaws, improving both aesthetics and functionality.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Dental Bridges.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Dental Bridges</p>
                <p class="text-justify text-[#424244]">Crowns are used to cover damaged or weakened teeth, while bridges replace missing teeth by anchoring artificial teeth to adjacent natural teeth, restoring both function and appearance.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Dental Implants.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Dental Implants</p>
                <p class="text-justify text-[#424244]">Implants are a permanent solution for tooth replacement. They involve the placement of artificial tooth roots in the jawbone, providing a stable foundation for prosthetic teeth.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Dentures.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Dentures</p>
                <p class="text-justify text-[#424244]">Removable appliances used to replace missing teeth and surrounding tissues. Full dentures replace an entire arch, while partial dentures are used when some natural teeth remain.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Root Canal.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Root Canal</p>
                <p class="text-justify text-[#424244]">A procedure to treat and save a tooth that is severely infected or decayed. It involves removing the damaged pulp, cleaning the canal, and sealing it to prevent further infection.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Periodontal Treatment.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Periodontal Treatment</p>
                <p class="text-justify text-[#424244]">Services for preventing, diagnosing, and treating gum diseases. This includes scaling and root planing to remove tartar and smooth root surfaces.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Oral Surgery.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Oral Surgery</p>
                <p class="text-justify text-[#424244]">Surgical procedures performed in the oral cavity, including tooth extractions, wisdom tooth removal, and other corrective surgeries.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Pediatric Dentistry.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Pediatric Dentistry</p>
                <p class="text-justify text-[#424244]">Specialized care for children, including preventive measures, education on oral hygiene, and early intervention for potential dental issues.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Mouth Guards.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Mouth Guards</p>
                <p class="text-justify text-[#424244]">Custom-made devices to protect teeth from injury during sports or to prevent teeth grinding (bruxism) during sleep.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Cosmetic Dentistry.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Cosmetic Dentistry</p>
                <p class="text-justify text-[#424244]">Various aesthetic treatments, such as veneers, bonding, and contouring, aimed at enhancing the overall appearance of the smile.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/Dental Sealants.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Dental Sealants</p>
                <p class="text-justify text-[#424244]">Sealants are thin, protective coatings applied to the chewing surfaces of molars and premolars to prevent cavities.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-8">
            <div class="p-4">
                <img src="../../images/emergency Dental Care.png" class="max-w-[50%] mx-auto block mb-4"/>
                <p class="text-lg text-[20px] mb-2 text-[#536ec8] text-center font-semibold">Emergency Dental Care</p>
                <p class="text-justify text-[#424244]">Dental clinics may offer emergency services for situations like severe toothaches, broken teeth, or injuries to the mouth.</p>
            </div>
            </div>

            <div class="w-full md:w-1/4 px-4 mb-24">
            <div class="p-4">

            </div>
            </div>
            
        </div>

        
        </div>
    </div>    

    );
}