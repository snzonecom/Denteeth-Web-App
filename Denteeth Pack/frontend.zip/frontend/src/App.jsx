import { Routes, Route } from 'react-router-dom'
import './App.css'
import IndexPage from './pages/IndexPage'
import LoginPage from './pages/LoginPage'
import Layout from './Layout'
import Services from './pages/Services'
import About from './pages/About'
import Contact from './pages/Contact'
import User from './pages/User'
import Dentists from './pages/Dentists'
import Appointment from './pages/Appointment'
import RegisterPage from './pages/RegisterPage'
import DentistA from './pages/DentistA'
import DentistB from './pages/DentistB'
import DentistC from './pages/DentistC'
import DentistD from './pages/DentistD'
import DentistE from './pages/DentistE'
import DentistF from './pages/DentistF'
import DentistG from './pages/DentistG'
import DentistH from './pages/DentistH'

function App() {

  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element = {<IndexPage />} />
        <Route path='/login' element={<LoginPage />} />
        <Route path='/services' element={<Services />} />
        <Route path='/about' element={<About />} />
        <Route path='/contact' element={<Contact />} />
        <Route path='/user' element={<User />} />
        <Route path='/dentists' element={<Dentists />} />
        <Route path='/appointment' element={<Appointment />} />
        <Route path='/register' element={<RegisterPage />} />
        <Route path='/dentista' element={<DentistA />} />
        <Route path='/dentistb' element={<DentistB />} />
        <Route path='/dentistc' element={<DentistC />} />
        <Route path='/dentistd' element={<DentistD />} />
        <Route path='/dentiste' element={<DentistE />} />
        <Route path='/dentistf' element={<DentistF />} />
        <Route path='/dentistg' element={<DentistG />} />
        <Route path='/dentisth' element={<DentistH />} />

      </Route>
    </Routes>

  )
}

export default App
