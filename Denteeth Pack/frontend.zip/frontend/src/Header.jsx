import {Link} from "react-router-dom";

export default function Header() {
    return(
        <header className='flex justify-between'>
  
        <a href="/" className="flex items-center gap-1 ms-8">
          <span className='font-bold text-xl text-[#002451]'>Denteeth.</span>
        </a>

        <div className="flex gap-3 py-5 px-4 text-[#424244]">

          <Link to={'/'}>HOME</Link>
          <div className="border-l border-transparent"></div>

          <Link to={'/services'}>SERVICES</Link>
          <div className="border-l border-transparent"></div>

          <Link to={'/dentists'}>DENTISTS</Link>
          <div className="border-l border-transparent"></div>

          <Link to={'/about'}>ABOUT</Link>
          <div className="border-l border-transparent"></div>

          <Link to={'/contact'}>CONTACT</Link>
        </div>
        <div className="flex items-center bg-[#536ec8] gap-3 border border-transparent-300 rounded-full py-3 px-4 mr-8">
        
        <Link className="flex" title = "login" to={'/user'} >
          <div className="bg-gray-500 text-white rounded-full border border-gray-500 overflow-hidden">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 relative top-1">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
            </svg>
          </div>
        </Link>
        <Link className="flex" title = "login" to={'/login'} >
          <svg xmlns="http://www.w3.org/2000/svg" fill="white" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 ml-2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
          </svg>
        </Link>
        </div>

      </header>
    );
}