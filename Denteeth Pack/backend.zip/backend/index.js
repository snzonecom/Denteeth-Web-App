const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const UserModel = require('./models/Users')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const cookieParser = require('cookie-parser')
const AppointmentModel = require('./models/Appointment');

const app = express()
app.use(express.json())

app.use(cors({
    origin: ['http://localhost:5173'],
    methods: ['GET','POST'],
    credentials: true
}))

app.use(cookieParser({ sameSite: 'none' }));

mongoose.connect("mongodb://127.0.0.1:27017/denteethdb")

app.post('/loginUser', (req, res) => {
    const { email, password } = req.body;
    UserModel.findOne({ email: email })
        .then(user => {
            if (user) {
                bcrypt.compare(password, user.password, (err, result) => {
                    if (result === true) {
                        const token = jwt.sign({email: user.email}, 'jwt-secret-key', {expiresIn: '1d'})
                        res.cookie('token', token);
                        res.json('success');
                    } else {
                        res.json('the password is incorrect');
                    }
                });
            } else {
                res.json('no record exists');
            }
        })
        .catch(err => {
            console.error(err);
            res.status(500).json('Internal Server Error');
        });
});

app.post('/registerUser', (req,res) => {
    const {fullName, contact, email, password} = req.body;
    bcrypt.hash(password, 10)
    .then(hash => {
        UserModel.create({fullName, contact, email, password: hash})
        .then(users => res.json({status: 'ok'}))
        .catch(err => res.json(err))
    }).catch(err => res.json(err))
    
})

app.post('/setAppointment', (req, res) => {
    const { fullName, email, contact, service, appointmentSched } = req.body;

    console.log('Received appointment data:', req.body);

    const newAppointment = new AppointmentModel({
        fullName,
        email,
        contact,
        service,
        appDate: appointmentSched,
    });

    newAppointment.save()
        .then(() => {
            console.log('Appointment saved successfully');
            res.json({ status: 'success' });
        })
        .catch((err) => {
            console.error('Error saving appointment:', err);
            res.status(500).json({ status: 'error', message: 'Internal Server Error' });
        });
});




app.listen(3001, () => {
    console.log("server is running")
})
