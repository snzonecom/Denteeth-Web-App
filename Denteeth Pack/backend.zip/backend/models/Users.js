const mongoose = require('mongoose')

const UserSchema = new mongoose.Schema({
    fullName: {
        type: String,
        unique: true
    },
    contact: String,
    email: {
        type: String,
        unique: true
    },
    password: String,
})

const UserModel = mongoose.model("users", UserSchema)
module.exports = UserModel