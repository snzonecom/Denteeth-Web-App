const mongoose = require('mongoose')

const AppointmentSchema = new mongoose.Schema({
    fullName: String,
    email: String,
    contact: String,
    service: String,
    appDate: Date,
})

const AppointmentModel = mongoose.model("appointment", AppointmentSchema)
module.exports = AppointmentModel